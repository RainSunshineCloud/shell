<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Full infrmation about theme, including $theme_generation and $theme_version
 *
 * @package PhpMyAdmin-test
 */
$theme_name = 'Test Theme';
$theme_generation = "2";
$theme_version = "0.3";
